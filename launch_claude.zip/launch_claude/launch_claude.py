import subprocess

# Define the command to run
command = "ollama launch claude --config"

# Use subprocess to run the command
try:
    subprocess.run(command, shell=True)
    print("Command executed successfully.")
except subprocess.CalledProcessError as e:
    print(f"Error executing command: {e}")